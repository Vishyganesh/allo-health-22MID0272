import StatusBadge from "./StatusBadge";

type Inventory = {
  warehouseId: string;
  warehouseName: string;
  totalStock: number;
  reservedStock: number;
  availableStock: number;
};

type Product = {
  id: string;
  name: string;
  imageUrl?: string;
  inventories: Inventory[];
};

type Props = {
  product: Product;

  onReserve: (
    productId: string,
    warehouseId: string
  ) => void;
};

export default function ProductCard({
  product,
  onReserve,
}: Props) {

  return (

    <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm hover:shadow-lg transition">

      <div className="flex items-center justify-between mb-5">

        <span className="bg-slate-100 text-slate-700 px-4 py-2 rounded-full text-sm font-semibold">
          {product.inventories.length} warehouses
        </span>

        <StatusBadge
          availableStock={
            product.inventories[0]
              ?.availableStock || 0
          }
        />
      </div>

      <img
        src={product.imageUrl}

        alt={product.name}

        className="w-full h-[320px] object-cover rounded-3xl mb-6"
      />

      <h2 className="text-3xl font-bold text-slate-900 mb-5">
        {product.name}
      </h2>

      <div className="space-y-3">

        {product.inventories.map(
          (inventory) => (

          <div
            key={inventory.warehouseId}
            className="flex items-center justify-between bg-slate-50 rounded-2xl p-4"
          >

            <div>

              <p className="font-semibold text-slate-900">
                {
                  inventory.warehouseName
                }
              </p>

              <p className="text-slate-500 text-sm">
                {
                  inventory.availableStock
                } available
              </p>
            </div>

            <button
              onClick={() =>
                onReserve(
                  product.id,
                  inventory.warehouseId
                )
              }

              className="bg-slate-900 text-white px-5 py-3 rounded-xl hover:bg-slate-700 transition"
            >
              Reserve
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}